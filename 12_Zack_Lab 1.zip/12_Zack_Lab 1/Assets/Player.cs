﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    float speed = 10.0f;
    float gravityModifier = 1.0f;
    Rigidbody playerRb;
    float jumpInit = 0;
    float jumpcount = 0;
    float gravitymodifier = 2.0f;
    // Start is called before the first frame update
    void Start()
    {
        
            playerRb = GetComponent<Rigidbody>();

            Physics.gravity *= gravityModifier;
       
    }

    
    void Update()
    {
        float verticalInput = Input.GetAxis("Vertical");
        float horizontalInput = Input.GetAxis("Horizontal");
       
        transform.Translate(Vector3.forward * Time.deltaTime * verticalInput * speed);
        transform.Translate(Vector3.right * Time.deltaTime * horizontalInput *speed);
        Jumpplayer();
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Ground"))
        {
            jumpInit = 0;
        }
    }
    private void Jumpplayer()
    {
        if (Input.GetKeyDown(KeyCode.Space) && jumpInit < 1)
        {
            playerRb.AddForce(Vector3.up * 10, ForceMode.Impulse);
            jumpcount++;
            jumpInit++;
            Debug.Log("jump count : " + jumpcount);
        }
    }

}
